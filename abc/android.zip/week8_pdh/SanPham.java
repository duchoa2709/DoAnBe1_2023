package tdc.edu.vn.week8_pdh;

import java.io.Serializable;

public class SanPham implements Serializable {
    String maSP, tenSp, soLuong;

    public SanPham() {
    }

    @Override
    public String toString() {
        return "SanPham{" +
                "maSP='" + maSP + '\'' +
                ", tenSp='" + tenSp + '\'' +
                ", soLuong=" + soLuong +
                '}';
    }

    public SanPham(String maSP, String tenSp, String soLuong) {
        this.maSP = maSP;
        this.tenSp = tenSp;
        this.soLuong = soLuong;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public String getTenSp() {
        return tenSp;
    }

    public void setTenSp(String tenSp) {
        this.tenSp = tenSp;
    }

    public String getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(String soLuong) {
        this.soLuong = soLuong;
    }
}
