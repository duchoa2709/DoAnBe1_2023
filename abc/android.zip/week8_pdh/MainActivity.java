package tdc.edu.vn.week8_pdh;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.SafeBrowsingResponse;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView lvDanhSach;
    public static ArrayList<SanPham> data_sp = new ArrayList<>();
    public static CustomAdapter customAdapter;
    Button btnThem, btnXoa, btnSua, btnThoat,btnChiTiet;
    EditText edtMaSP,edtTenSP,edtSoLuong;
    int index = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setControl();
        setEvent();
        
    }

    private void setEvent() {
        KhoiTao();
        customAdapter = new CustomAdapter(this,R.layout.layout_item,data_sp);
        lvDanhSach.setAdapter(customAdapter);

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SanPham sp = new SanPham();
                sp.setMaSP(edtMaSP.getText().toString());
                sp.setTenSp(edtTenSP.getText().toString());
                sp.setSoLuong(edtSoLuong.getText().toString());
                data_sp.add(sp);
                customAdapter.notifyDataSetChanged();
            }
        });

        lvDanhSach.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                index = position;
                SanPham sp = data_sp.get(position);
                edtMaSP.setText(sp.getMaSP());
                edtTenSP.setText(sp.getTenSp());
                edtSoLuong.setText(sp.getSoLuong());
            }
        });

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data_sp.remove(index);
                customAdapter.notifyDataSetChanged();
                btnThoat.callOnClick();
            }
        });

        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SanPham sp = data_sp.get(index);
                sp.setMaSP(edtMaSP.getText().toString());
                sp.setTenSp(edtTenSP.getText().toString());
                sp.setSoLuong(edtSoLuong.getText().toString());
                customAdapter.notifyDataSetChanged();
            }
        });

        btnThoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void KhoiTao() {
        data_sp.add(new SanPham("sp1", "iphone", "300"));
        data_sp.add(new SanPham("sp2", "SamSung", "200"));

    }

    private void setControl() {
        lvDanhSach = findViewById(R.id.lvDanhSach);
        edtMaSP = findViewById(R.id.edtMaSp);
        edtTenSP = findViewById(R.id.edtTenSP);
        edtSoLuong = findViewById(R.id.edtSoLuong);
        btnThem = findViewById(R.id.btnThem);
        btnXoa = findViewById(R.id.btnXoa);
        btnSua = findViewById(R.id.btnSua);
        btnThoat = findViewById(R.id.btnThoat);

    }
}
