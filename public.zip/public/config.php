<?php
/** The name of the database*/
define( 'DB_NAME', 'demo' );
/** MySQL database username */
define( 'DB_USER', 'root' );
/** MySQL database password */
define( 'DB_PASSWORD', 'root' );
/** MySQL hostname */
define( 'DB_HOST', 'localhost' );
/** port number of DB */
define( 'PORT', 3306);
/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );
?>