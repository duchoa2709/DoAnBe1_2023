package tdc.edu.vn.week8_pdh;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter<SanPham> {

    Context context;
    int resource;
    ArrayList<SanPham> data;
    public CustomAdapter(@NonNull Context context, int resource, ArrayList<SanPham> data) {
        super(context, resource, data);
        this.context = context;
        this.resource = resource;
        this.data = data;
    }

    @NonNull
    @Override
    public View getView(final int position, @NonNull View convertView, @NonNull ViewGroup parent) {
        convertView = LayoutInflater.from(context).inflate(resource,null);
        TextView tvMa =convertView.findViewById(R.id.tvMaSP);
        TextView tvTenSp =convertView.findViewById(R.id.tvTenSP);
        TextView tvSoLuong =convertView.findViewById(R.id.tvSoLuong);

        Button btnChiTiet = convertView.findViewById(R.id.btnChiTiet);

        final SanPham sp = data.get(position);
        tvMa.setText(sp.getMaSP());
        tvTenSp.setText(sp.getTenSp());
        tvSoLuong.setText(sp.getSoLuong());

        btnChiTiet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context,ChiTiet.class);
                intent.putExtra("sp", sp);
                intent.putExtra("index",position);
                context.startActivity(intent);
            }
        });
        return convertView;
    }
}
