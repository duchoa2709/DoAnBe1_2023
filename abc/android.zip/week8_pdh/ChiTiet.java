package tdc.edu.vn.week8_pdh;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class ChiTiet extends AppCompatActivity {
    ArrayList<SanPham> data_sp = new ArrayList<>();
    CustomAdapter customAdapter;
    EditText edtMaSP, edtTenSP, edtSoLuong;
    Button btnXoa,btnSua,btnQuayLai;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet);
        setControl();
        setEvent();
    }

    private void setEvent() {
        final int index = getIntent().getIntExtra("index", -1);
        //Toast.makeText(this, "index"+index,Toast.LENGTH_LONG).show();
        SanPham sp = (SanPham) getIntent().getSerializableExtra("sp");

        edtMaSP.setText(sp.getMaSP());
        edtTenSP.setText(sp.getTenSp());
        edtSoLuong.setText(sp.getSoLuong());

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.data_sp.remove(index);
                MainActivity.customAdapter.notifyDataSetChanged();
                onBackPressed();
            }
        });
        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SanPham sp = MainActivity.data_sp.get(index);
                sp.setMaSP(edtMaSP.getText().toString());
                sp.setTenSp(edtTenSP.getText().toString());
                sp.setSoLuong(edtSoLuong.getText().toString());
                MainActivity.customAdapter.notifyDataSetChanged();
                onBackPressed();
            }
        });
        btnQuayLai.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }
    private void setControl() {
        edtMaSP = findViewById(R.id.edtMaSp);
        edtTenSP = findViewById(R.id.edtTenSP);
        edtSoLuong = findViewById(R.id.edtSoLuong);

        btnXoa = findViewById(R.id.btnXoa);
        btnSua = findViewById(R.id.btnSua);
        btnQuayLai = findViewById(R.id.btnQuayLai);
    }
}
